#include<stdio.h>
int main(){
    // int a=20;
    printf("hello world!");
    return 0;
}