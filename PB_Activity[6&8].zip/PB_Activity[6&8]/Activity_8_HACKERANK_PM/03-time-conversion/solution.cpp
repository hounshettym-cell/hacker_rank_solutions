#include <bits/stdc++.h>

using namespace std;

/*
 * Complete the 'timeConversion' function below.
 *
 * The function is expected to return a STRING.
 * The function accepts STRING s as parameter.
 */

string timeConversion(string s) {
    // Extract the AM/PM part
    string period = s.substr(8, 2);
    
    // Extract the hour and convert it to an integer
    int hour = stoi(s.substr(0, 2));
    
    // Extract the minutes and seconds
    string rest = s.substr(2, 6);
    
    if (period == "AM") {
        if (hour == 12) {
            hour = 0; // 12 AM is 00 in 24-hour time
        }
    } else { // PM
        if (hour != 12) {
            hour += 12; // Add 12 for PM times (except 12 PM)
        }
    }
    
    // Format the new hour back to a 2-digit string
    string newHour = to_string(hour);
    if (newHour.length() == 1) {
        newHour = "0" + newHour;
    }
    
    // Return the combined result
    return newHour + rest;
}

int main()
{
    ofstream fout(getenv("OUTPUT_PATH"));

    string s;
    getline(cin, s);

    string result = timeConversion(s);

    fout << result << "\n";

    fout.close();

    return 0;
}